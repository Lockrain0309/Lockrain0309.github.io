import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class Texter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String server = "jdbc:mysql://127.0.0.1:3306/";
		String database = "final_project"; // change to your own database
		String url = server + database + "?useSSL=false";
		String username = "root";
		String password = "";
		
		try {
			Connection conn = DriverManager.getConnection(url, username, password);
			System.out.println("DB Connectd");
			SqlManager sql = new SqlManager(conn);
		

			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
