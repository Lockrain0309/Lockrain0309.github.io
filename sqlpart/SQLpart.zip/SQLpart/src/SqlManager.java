import java.sql.*;
import java.time.LocalDateTime;

public class SqlManager {
	Connection conn;
	Statement stat;
	private String account = "account";
	private String book = "book";
	private String history = "history";
	private String columns;
	private String data;
	private String condition;
	
	public SqlManager (Connection conn) throws SQLException{
		this.conn = conn;
		stat = conn.createStatement();
	}
	
	//註冊用method
	public void enroll(String account,String password,String username,String department) {
		columns = "Account,Password,UserName,Department_level,ShoppingCartID";
		data = String.format("'%s','%s','%s','%s','%s'",account,password,username,department,"0");
		addData(this.account,columns,data);
	}
	
	//賣書method
	public void addBook(String name,String price,String author,String publisher,String isbn,String department,String professer,String sellerID,String contact,String img,String remark) {
		columns = "Name, Price, Author,publisher,ISBN,Department,Professer,SellerID,contact,Remark,ImgPath,State";
		data = String.format("'%s','%s','%s','%s','%s','%s','%s','%s','%s','s','%s','%s'",name,price,author,publisher,isbn,department,professer,sellerID,contact,remark,img,0);
		addData(book,columns,data);
	}
	
	//檢查登入
	public boolean checkSign(String account,String password) {
		boolean correct = false;
		if(!checkAccount(account)) {
			correct = false;
		}else {
			search("Password",this.account,String.format("Account =  '%s' ", account));
			correct = true;
		}
		return correct;
	}
	
	//修改密碼
	public void changePassword(String account, String newPassword) {
		String query;
		query = String.format("UPDATE %s\n SET Password = %s\n WHERE Account = '%s';",this.account,newPassword,account);
		
		try {
			stat.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//修改賬戶相關資訊
	public void changeAccInfo(String account,String setCol,String changeInfo) {
		String query;
		boolean sucess;
		query = String.format("UPDATE %s\n SET %s = %s\n WHERE Account = '%s';",this.account,setCol,changeInfo,account);
		
		try {
			stat.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//修改書本相關資訊
	public void changebookInfo(String name, String setCol, String changeInfo) {
		String query;
		boolean sucess;
		query = String.format("UPDATE %s\n SET %s = %s\n WHERE Name = '%s';", this.book, setCol, changeInfo, name);

		try {
			stat.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//購入書時的記錄
	public void record(String bookID,String sellerID,String BuyerID,LocalDateTime localDateTime) {
		addData(this.history,"`BookID`, `SellerID`, `BuyerID`, `Time`",String.format("'%s','%s','%s','%s'",
				bookID,sellerID,BuyerID,localDateTime));
	}
		
	
	//檢查Account是否存在
	public boolean checkAccount(String account) {
		boolean exist = false;
		String query;
		boolean sucess;
		columns = "Account";
		condition = String.format("Account = '%s'",account);
		query = String.format("SELECT %s From %s WHERE %s",columns,this.account,condition);
		
		try {
			sucess = stat.execute(query);
			if (!sucess) {
				exist = false;
			}else {
				exist = true;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return exist;
	}
	
	//取得accountID
	public String getID(String account) {
		String id = "";
		id = search("ID",this.account,String.format("Account = %s", account));
		return id;
	}
	
	//取得bookID
	public String getID(String columns,String input) {
		String id = "";
		id = search("ID",this.book,String.format("%s = %s", columns, input));
		return id;
	}
	
	//取得書特定的資訊
	public String getInformation(String wantedInformation,String columns,String input) {
		String information = "";
		information = search(wantedInformation,this.book,String.format("%s = %s", columns, input));
		return information;
	}
	
	//取得買書記錄
	public String getBuyHistory(String id) {
		String output = "";
		output = search("*",history,String.format("BuyerID = %s",id));
		return output;
	}
	//取得賣書記錄
	public String getSellHistory(String id) {
		String output = "";
		output = search("*",history,String.format("SellerID = %s",id));
		return output;
	}
	
	public String search(String columns,String table,String condition) {
		String output = "";
		String query;
		boolean sucess;
		query = String.format("SELECT %s From %s WHERE %s",columns,table,condition);
		
		try {
			sucess = stat.execute(query);
			if (sucess) {
				ResultSet result = stat.getResultSet();
				output = showResultSet(result);
				result.close();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}
	
	public void addData(String table,String columns,String data) {
		String query;
		boolean sucess;
		query = String.format("INSERT INTO `%s`(%s)VALUES(%s)",table,columns,data);
		
		try {
			stat.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void delete(String table,String condition) {
		String query;
		boolean sucess;
		query = String.format("DELETE FROM `%s` WHERE %s",table,condition);
		
		try {
			stat.execute(query);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String showResultSet(ResultSet result) throws SQLException {
	       ResultSetMetaData metaData = result.getMetaData();
	       int columnCount = metaData.getColumnCount();
	       String output = "";
	       for (int i = 1; i <= columnCount; i++) {
	              output += String.format("%15s", metaData.getColumnLabel(i));
	       }
	       output += "\n";
	       
	       while (result.next()) {
	              for (int i = 1; i <= columnCount; i++) {
	                    output += String.format("%15s", result.getString(i));
	              }
	              output += "\n";
	       }
	       return output;
	}
	
	//可用於顯示error sentence
	class AccountError extends Exception {
		public AccountError(String Error){
		super(Error);
		}
	}
}
    
